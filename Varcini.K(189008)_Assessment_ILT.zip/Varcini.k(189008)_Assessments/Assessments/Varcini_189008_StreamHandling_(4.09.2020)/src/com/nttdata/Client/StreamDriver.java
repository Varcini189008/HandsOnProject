package com.nttdata.Client;

import java.util.ArrayList;
import java.util.List;

public class StreamDriver {

	public static void main(String[] args) {
		
		List<Employee> list=new ArrayList<>();
		list.add(new Employee(12,"Varsha",1000));
		list.add(new Employee(13,"Preethi",23000));
		list.add(new Employee(14,"Seetha",13000));
		list.add(new Employee(15,"Deepak",7000));
		list.add(new Employee(16,"Subharna",45000));
		list.add(new Employee(17,"Nandhu",9000));
		list.stream().filter(emp->emp.getSalary() >10000).forEach(System.out::println);
		long x=list.stream().filter(emp->emp.getSalary()>10000).count();
		System.out.println("Number of Employees have salary more than 10000 is :"+x);
		

	}

}
