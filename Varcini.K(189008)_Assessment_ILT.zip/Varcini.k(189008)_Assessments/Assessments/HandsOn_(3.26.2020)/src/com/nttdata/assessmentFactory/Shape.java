package com.nttdata.assessmentFactory;

public interface Shape {

	
	void Area(int a,int b);
	
}
