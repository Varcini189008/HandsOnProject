package com.nttdata;

public class Book {
	
	private String bookName;
	private double bookPrice;
	public String getBookName() {
		return bookName;
	}
	public void setBookName(String bookName) {
		this.bookName = bookName;
	}
	public double getBookPrice() {
		return bookPrice;
	}
	public void setBookPrice(double bookPrice) {
		this.bookPrice = bookPrice;
	}
	public void show()
	{
		System.out.println("the book name is:  " +bookName);
		System.out.println("the book price is: " +bookPrice);
	}
	
}
