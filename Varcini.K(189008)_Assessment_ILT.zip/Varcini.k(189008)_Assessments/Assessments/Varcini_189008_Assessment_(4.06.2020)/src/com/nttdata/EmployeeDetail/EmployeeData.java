package com.nttdata.EmployeeDetail;

public class EmployeeData {
	private int empID;
	private String name;
	private double salary;
	private String grade;
	private String mobileNumber;
	private String emailID;
	private String address;
	
	public EmployeeData(int empID, String name, double salary, String grade, String mobileNumber, String emailID,
			String address) {
		super();
		this.empID = empID;
		this.name = name;
		this.salary = salary;
		this.grade = grade;
		this.mobileNumber = mobileNumber;
		this.emailID = emailID;
		this.address = address;
	}

	@Override
	public String toString() {
		return "EmployeeData [empID=" + empID + ", name=" + name + ", salary=" + salary + ", grade=" + grade
				+ ", mobileNumber=" + mobileNumber + ", emailID=" + emailID + ", address=" + address + "]";
	}
	

}
