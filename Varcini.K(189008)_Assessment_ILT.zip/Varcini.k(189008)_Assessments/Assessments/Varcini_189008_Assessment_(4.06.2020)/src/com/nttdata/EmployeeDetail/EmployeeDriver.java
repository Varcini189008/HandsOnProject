package com.nttdata.EmployeeDetail;

import java.util.ArrayList;

public class EmployeeDriver {

	public static void main(String[] args) {
		EmployeeData emp=new EmployeeData(189008,"Varsha",25000,"A","9092625263","varcini26@gmail.com","Bangalore");
		EmployeeData emp1=new EmployeeData(189018,"Deepak",29000,"A","9092425263","jayadeepak04@gmail.com","Bangalore");
		EmployeeData emp2=new EmployeeData(189028,"Latha",25400,"B","9092325263","latha@gmail.com","Bangalore");
		ArrayList<EmployeeData> list=new ArrayList<EmployeeData>();
		list.add(emp);
		list.add(emp1);
		list.add(emp2);
		for(EmployeeData e:list)
		{
			System.out.println("Employee Details are:  "+e);
			
		}

	}

}
