package com.nttdata.inheritance;

public class Vehicle {
	private int vehicleNo;
	private String name;
	private double price;
	private String model;
	public Vehicle(int vehicleNo, String name, double price, String model) {
		super();
		this.vehicleNo = vehicleNo;
		this.name = name;
		this.price = price;
		this.model = model;
	}
	void display()
	{
		System.out.println("Vehicle Number : "+vehicleNo + "  Vehicle Name :"+name+ " Vehicle price : "+price+" Vehicle Model :" +model);
	}
	
	}
