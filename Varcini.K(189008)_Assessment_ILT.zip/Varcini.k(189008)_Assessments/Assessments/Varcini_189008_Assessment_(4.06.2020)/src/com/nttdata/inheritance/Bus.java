package com.nttdata.inheritance;

public class Bus extends Vehicle {

	public Bus(int vehicleNo, String name, double price, String model) {
		super(vehicleNo, name, price, model);
		
	}
	void display()
	{
		System.out.println("Bus Details");
		super.display();
	}

	void status(String x)
	{
		
		switch(x)
		{
		case"1":
			System.out.println("to start the Bus");
			break;
		case "2":
		
			System.out.println("to stop the Bus");
			break;
		case"q":
			System.exit(0);
		
		
		
		}
}
}
