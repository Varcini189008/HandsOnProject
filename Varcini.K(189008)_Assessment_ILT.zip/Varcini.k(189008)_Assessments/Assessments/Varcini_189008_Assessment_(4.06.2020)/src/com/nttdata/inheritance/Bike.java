package com.nttdata.inheritance;

public class Bike extends Vehicle{

	public Bike(int vehicleNo, String name, double price, String model) {
		super(vehicleNo, name, price, model);
		
	}
	void display()
	{
		System.out.println("Bike Details");
		super.display();
	}
	void status(String x)
	{
		
		switch(x)
		{
		case"1":
			System.out.println("to start the Bike");
			break;
		case "2":
		
			System.out.println("to stop the Bike");
			break;
		case"q":
			System.exit(0);
		
		
		
		}
}

}
