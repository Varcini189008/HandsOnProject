package com.nttdata.inheritance;

import java.util.Scanner;

public class VehicleDriver {

	public static void main(String[] args) {
		System.out.println("Welcome to Vehicle Simulation");
		Scanner s=new Scanner(System.in);
		int x;
		String y;
		int i=1;
		while(i==1)
		{
			System.out.println("Press below numbers for more details");
			System.out.println("1.Car 2.Bike 3.Bus 4.exit");
			x=s.nextInt();
			switch(x)
			{
			case 1:
				Car c= new Car(7896,"FERRARI",520000000,"Ferrari812");
				c.display();
				System.out.println("enter 1.to start, 2.to stop,3.q to exit");
				c.status(y=s.next());
				break;
			case 2:
				Bike b=new Bike(2605,"ROYAL ENFIELD",155000,"classic350");
				b.display();
				System.out.println("enter 1.to start, 2.to stop ,3.q to exit");
				b.status(y=s.next());
				break;
			case 3:	
				Bus b1=new Bus(4605,"Maruthi",15500,"Eicher");
				b1.display();
				System.out.println("enter 1.to start, 2.to stop,3.q to exit");
				b1.status(y=s.next());
				break;
			case 4:
				i=2;
				break;
			default:
				System.out.println("Invalid Option");
					
				
			}
			
			
		}
		

	}


}
