package com.nttdata.inheritance;

public class Car extends Vehicle {

	public Car(int vehicleNo, String name, double price, String model) {
		super(vehicleNo, name, price, model);
		
	}
	
	void display()
	{
		System.out.println("Car Details");
		super.display();
	}
	void status(String x)
	{
	
		
		switch(x)
		{
		case"1":
			System.out.println("to start the car");
			break;
		case "2":
		
			System.out.println("to stop the car");
			break;
		case"q":
			System.exit(0);
		
		
		
		}
		}
}


