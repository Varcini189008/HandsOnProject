package com.nttdata.EmployeeDaoImpl;

import java.util.List;

import com.nttdata.EmployeeDao.EmployeeDao;
import com.nttdata.Model.Employee;

public class EmployeeDaoImpl implements EmployeeDao{

	@Override
	public Employee createEmployee() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Employee> listEmployee() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String deleteEmployee() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Employee getByEmployeeID(int id) {
		// TODO Auto-generated method stub
		return null;
	}
	@Override
	public Employee searchEmployeeByName(String name) {
		// TODO Auto-generated method stub
		return null;
	}
	
}
