package com.nttdata.EmployeeDao;

import java.util.List;

import com.nttdata.Model.Employee;

public interface EmployeeDao {
	Employee createEmployee();
	List<Employee> listEmployee();
	String deleteEmployee();
	Employee getByEmployeeID(int id);
	Employee searchEmployeeByName(String name);


}
