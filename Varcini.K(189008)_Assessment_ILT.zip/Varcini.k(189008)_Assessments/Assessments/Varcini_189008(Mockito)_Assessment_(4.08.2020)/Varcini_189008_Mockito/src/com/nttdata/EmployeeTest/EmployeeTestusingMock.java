package com.nttdata.EmployeeTest;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import org.mockito.Mockito;

import com.nttdata.EmployeeDao.EmployeeDao;
import com.nttdata.Model.Employee;

public class EmployeeTestusingMock {
	EmployeeDao employeeDao=Mockito.mock(EmployeeDao.class);

	@Test
	public void testListEmployee() {
		List<Employee> list=new ArrayList<>();
		list.add(new Employee(12,"Deepak",23455));
		list.add(new Employee(13,"Varsha",98675));
		list.add(new Employee(14,"Preethi",45789));
		list.add(new Employee(15,"jayani",14578));
		list.add(new Employee(16,"Sabari",45678));
		Mockito.when(employeeDao.listEmployee()).thenReturn(list);
		
		
		
	}
	@Test
	public void testCreateEmployee()
	{
		Employee emp=new Employee(17,"Latha",67890);
		Mockito.when(employeeDao.createEmployee()).thenReturn(emp);
	}
	@Test
	public void testDeleteEmployee()
	{
		Employee emp=new Employee(16,"Sabari",45678);
		Mockito.when(employeeDao.deleteEmployee()).thenReturn("Deleted data");
	}
	@Test
	public void testgetByEmployeeId()
	{
		Employee employee=new Employee(17,"Latha",67890);
		Mockito.when(employeeDao.getByEmployeeID(107)).thenReturn(employee);
	}
	@Test
	public void testsearchEmployeeByName()
	{
		Employee employee=new Employee(12,"Deepak",23455);
		Mockito.when(employeeDao.searchEmployeeByName("Deepak")).thenReturn(employee);
	}

}
