package com.ntt.test;

import java.util.Calendar;
import java.util.Date;

public class RegularStudent extends Record {

	public RegularStudent(String name, Date start) {
		super(name);
		this.profession=" Regular Student";
		this.startDate= start;
		Calendar c=Calendar.getInstance();
		c.setTime(this.startDate);
		c.add(Calendar.YEAR, 70);
		this.complete=c.getTime();
	}

	@Override
	public void Database() {
		System.out.println("Added toRegular Student Database");
		
	}}