package com.ntt.test;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class School {

	public static void main(String[] args) {
		List<Record> list =new ArrayList<Record>();
		list.add(new ArrearStudent("varcini",new Date()));
		list.add(new RegularStudent("madhu",new Date()));
		list.add(new Staff("sabari"));
		for(Record a: list)
		{
			a.Database();
			
		}
		
	}

}
