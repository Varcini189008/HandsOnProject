package com.ntt.test;

import java.util.Date;

abstract class Record{
String name;
String profession;
Date startDate;
Date complete;
public Record(String name)
{
this.name=name;	
}
public abstract void Database();
}

