package com.ntt.test;

public class Staff extends Record{

	public Staff(String name) {
		super(name);
		this.profession="Staff Enquiry";
	}

	@Override
	public void Database() {
		System.out.println(" Added to Staff Database");
	}

}
