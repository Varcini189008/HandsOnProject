package com.ntt.test;

import java.util.Calendar;
import java.util.Date;

public class ArrearStudent extends Record{

	
	public ArrearStudent(String name, Date start) {
		super(name);
		this.profession=" Arrear Student";
		this.startDate= start;
		Calendar c=Calendar.getInstance();
		c.setTime(this.startDate);
		c.add(Calendar.YEAR, 70);
		this.complete=c.getTime();
	}

	@Override
	public void Database() {
		System.out.println(" Added to Arrear Student  Database");
		
	}

}