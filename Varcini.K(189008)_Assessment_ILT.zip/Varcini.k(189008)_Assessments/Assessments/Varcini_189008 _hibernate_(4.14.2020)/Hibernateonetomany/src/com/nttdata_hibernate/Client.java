package com.nttdata_hibernate;

import java.util.HashSet;
import java.util.Set;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class Client {
	public static void main(String[] args){
		
		Configuration cfg=new Configuration();
		cfg.configure("HibernateConfig.xml");
		
		SessionFactory fc=cfg.buildSessionFactory();
		Session session=fc.openSession();
		
		Product product=new Product();
		product.setProductId(001);
		product.setProductName("FRIDGE");
	
		
		Category c1=new Category();
		c1.setCategoryId(01);
		c1.setCategoryName("LG");
		
		Category c2=new Category();
		c2.setCategoryId(02);
		c2.setCategoryName("SAMSUNG");
		
		Category c3=new Category();
		c3.setCategoryId(03);
		c3.setCategoryName("WHIRLPOOL");
	
		
		Set s=new HashSet<>();
		s.add(c1);
		s.add(c2);
		s.add(c3);
	
		
		product.setChildren(s);
		
		Transaction tx=session.beginTransaction();
		session.save(product);
		tx.commit();
		System.out.println("one to many");
		session.close();
		fc.close();
		
	}

}
