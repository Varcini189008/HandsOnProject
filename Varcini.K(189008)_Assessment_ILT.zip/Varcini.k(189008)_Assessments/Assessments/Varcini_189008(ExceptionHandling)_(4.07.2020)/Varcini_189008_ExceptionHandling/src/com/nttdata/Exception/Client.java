package com.nttdata.Exception;

import java.util.Scanner;


public class Client {
public static void main(String[] args) {
	System.out.println("Welcome to Bank Application");
	Scanner scanner=new Scanner(System.in);
	int i=1;
	while(i==1)
	{
		System.out.println("Press Below option  1.Create Account 2.Transfer Funds 3.quit");
		int option= scanner.nextInt();
		Account user1=new Account();
		switch (option) {
		case 1:
		{	
			
			System.out.println("press 1.to create new account 2. repeat account creation 3.to quit");
            int op=scanner.nextInt();
            if(op==1)
            {
            	
            	user1.CreateFirstAccount();
            }
            else if(op==2)
            {
            
        	user1.CreateSecondAccount();
            	
            }
            else if(op==3)
            {
            	i=0;
            }
            else
            {
            	System.out.println("Enter valid data");
            }
			break;
		}
		case 2:
		{	
			System.out.println("press 1 to transfer from user1 to user2");
			System.out.println("press 2 to transfer from user2 to user1");
			int op=scanner.nextInt();
			if(op==1)
			{
		
				System.out.println("enter the amount to transfer");
				double tamount=scanner.nextDouble();
			user1.tranferfunds(tamount);
				
				}
			else if(op==2)
			{
				System.out.println("enter the amount to transfer");
				double tamount=scanner.nextDouble();
				Account a1=new Account();
		
				a1.tranferfunds(tamount);

			}
			else
			{
				System.out.println("enter valid data");
			}
			break;
		}
		case 3:
		{	
			i=0;
			break;
		}
		default:
			break;
		}
		
	}
}
}
