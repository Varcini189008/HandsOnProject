package com.nttdata.Exception;

public class Bank {
	private String AccountHolderName;
	private int AccountId;
	private double balance;
	private double minbal=1000;
	public Bank(String accountHolderName, int accountId, double balance, double minbal) {
		super();
		AccountHolderName = accountHolderName;
		AccountId = accountId;
		this.balance = balance;
		this.minbal = minbal;
	}
	@Override
	public String toString() {
		return "Bank [AccountHolderName=" + AccountHolderName + ", AccountId=" + AccountId + ", balance=" + balance
				+ ", minbal=" + minbal + "]";
	}
	
	
}
