package com.nttdata.Exception;

public class InsufficientAmount extends Exception{
	public InsufficientAmount(String message)
	{
		super(message);
	}

}
