package com.nttdata.Exception;

import java.util.ArrayList;
import java.util.Scanner;



public class Account {
	private String AccountHolderName;
	private int AccountId;
	private Double balance;
	private Double balance1;
	public Double getBalance1() {
		return balance1;
	}
	public void setBalance1(Double balance1) {
		this.balance1 = balance1;
	}
	public double minbal=1000;
	Scanner scanner= new Scanner(System.in);
	ArrayList<Bank> list = new ArrayList<Bank>();
	private Account user1;
	private Account user2;
public void CreateFirstAccount()
{
System.out.println("Enter the Account1 Holder Name");
String AccountHolderName=scanner.next();
System.out.println("Enter the Account1 Id");
setAccountId(scanner.nextInt());
System.out.println("Enter the amount to account1");
balance=scanner.nextDouble();
Bank user1 = new Bank(AccountHolderName, AccountId, balance, minbal);
list.add(user1);
for(Bank e: list)
{
	
System.out.println(e);}
System.out.println("Successfully created");
}
public void CreateSecondAccount()
{
System.out.println("Enter the Account2 Holder  Name");
 String AccountHolderName1=scanner.next();
System.out.println("Enter the Account2 Id");
setAccountId(scanner.nextInt());
int AccountId1=scanner.nextInt();
System.out.println("Enter the amount to account2");
double balance1=scanner.nextDouble();
Bank user2 = new Bank(AccountHolderName, AccountId, balance, minbal);
list.add(user2);
for(Bank e: list)
{
System.out.println(e);
}

System.out.println("Successfully created");
}
public void tranferfunds(double transfer)
{
	System.out.println("your request to transfer "+transfer);
Double sbalance=user1.getBalance();

Double rbalance=user2.getBalance();
	

	if((sbalance-transfer)>minbal)
	{
	
	System.out.println("Successfully transfered");
	}
else
	{
	try {
		throw new InsufficientAmount("sorry you dont have required amount to transfer");
	} catch (InsufficientAmount e) {
		e.printStackTrace();
	}}
}
public String getAccountHolderName() {
	return AccountHolderName;
}
public void setAccountHolderName(String accountHolderName) {
	AccountHolderName = accountHolderName;
}
public Double getBalance() {
	return balance;
}
public void setBalance(Double balance) {
	this.balance = balance;
}
public int getAccountId() {
	return AccountId;
}
public void setAccountId(int accountId) {
	AccountId = accountId;
}
}
